#include "CsvReader.h"

CsvReader::CsvReader(const char *filePath)
{
    path = new char[strlen(filePath)];
    strcpy(path, filePath); 
}

CsvReader::~CsvReader()
{
    delete [] path; 
}

CSV_RESULT * CsvReader::read(const bool skipFirstLine) // a generic csv reader which i can use in numerus 
{                                                      // situations . I did it that way for achiving                  
    CSV_RESULT * rows = new CSV_RESULT();              // abstractions (means this block of code is reusable)
    ifstream infile(path);                             // i heard that its common practice and yea .......
                                                       // soooo there is an option for skipping first line
    int bufferSize = 1024;                             // and you can read every csv no matter collums
    char line[bufferSize];
    
    int cn = 0;

    while( infile.getline( line, bufferSize ) )
    {  
        if (!(skipFirstLine && cn == 0)) { 

            CString * str = new CString(line);

            vector<CString*>* data = str->split(";");   // i choose ; for delimiter (the same on csv's)

            rows->push_back(data); 

        }
        cn++;
    }

    return rows; 
}
