
#include <stdio.h>
#include <iostream>

#include "CString.h"
#include "CsvReader.h"
#include "Grades.h"
#include "Students.h"
#include "Courses.h"
#include "Lists.h"

using namespace std;

// the lists 

vector<Grades *> *allGrades;
vector<Students *> *allStudents;
vector<Courses *> *allCourses;


// readers  ==============

vector<Grades *> *readGrades()                        //reading and pushing the data from grades csv (using the generic csv reader)
{
    CsvReader readerGrades("/home/bill/Desktop/Projects/CppGrades/docs/grades.csv");    // change to where your file of grades is
    CSV_RESULT *rows = readerGrades.read(true);

    int rowCount = rows->size();

    vector<Grades *> *allGrades = new vector<Grades *>();

    for (int i = 0; i < rowCount; i++)
    {
        auto row = *((*rows)[i]);

        auto AM = row[0];
        auto courseCode = row[1];

        float gradeVal = atof(row[2]->getWord());

        Grades *grade = new Grades(AM, courseCode, gradeVal);

        allGrades->push_back(grade);
    }

    return allGrades;
}

vector<Students *> *readStudents()              //reading and pushing the data from students csv (using the generic csv reader)
{
    CsvReader readerStudents("/home/bill/Desktop/Projects/CppGrades/docs/students.csv");    // change to where your file of students is
    CSV_RESULT *rows = readerStudents.read(true);

    int rowCount = rows->size();

    vector<Students *> *allStudents = new vector<Students *>();

    for (int i = 0; i < rowCount; i++)
    {
        auto row = *((*rows)[i]);

        auto AM = row[0];
        auto Surname = row[1];
        auto Name = row[2];

        Students *student = new Students(AM, Name, Surname);
        allStudents->push_back(student);
    }

    return allStudents;
}

vector<Courses *> *readCourses()                   //reading and pushing the data from courses csv (using the generic csv reader)
{
    CsvReader readerCourses("/home/bill/Desktop/Projects/CppGrades/docs/courses.csv");  // // change to where your file of courses is
    CSV_RESULT *rows = readerCourses.read(true);

    int rowCount = rows->size();

    vector<Courses *> *allCourses = new vector<Courses *>();

    for (int i = 0; i < rowCount; i++)
    {
        auto row = *((*rows)[i]);

        bool hasOld = row.size() > 2;

        CString *oldCode = NULL;
        CString *oldTitle = NULL;
        CString *newCode = NULL;
        CString *newTitle = NULL;

        if (hasOld)
        {
            newCode = row[0];
            newTitle = row[1];
            oldCode = row[2];
            oldTitle = row[3];
        }
        else
        {
            newCode = row[0];
            newTitle = row[1];
        }

        Courses *course = new Courses(newCode, newTitle, oldCode, oldTitle, hasOld);
        allCourses->push_back(course);
    }

    return allCourses;
}

// end readers ====================



// helper functions =====================

// wanted to seperate courses by old and new (cause ill check if grade old == grade new only in old course)

struct course_grade_t               
{
    Courses *course;
    bool isOld;
};

course_grade_t getCourseFromGrade(CString *gradeCode)           // finding the course from its code (so searching in grades csv)
{                                                               // returning the struct if course is old or new or null
    int courseCount = allCourses->size();

    for (int k = 0; k < courseCount; k++)
    {
        Courses *curCourse = (*allCourses)[k];
        CString newCode = *(curCourse->getNewCourseCode());

        if (newCode == *gradeCode)
        {
            course_grade_t re;
            re.course = curCourse;
            re.isOld = false;
            return re;
        }

        if (curCourse->getOldCourseCode() != NULL)
        {
            CString oldCode = *(curCourse->getOldCourseCode());

            if (oldCode == *gradeCode)
            {
                course_grade_t re;
                re.course = curCourse;
                re.isOld = true;
                return re;
            }
        }
    }
    course_grade_t re;
    re.course = NULL;
    return re;
}

Grades *getNewGrade(CString *newCourseCode, CString *AM)        // getting the match of its new grade
{
    int allGradesCn = allGrades->size();
    for (int i = 0; i < allGradesCn; i++)
    {
        Grades *grade = (*allGrades)[i];

        if ((*grade->getAM()) == *AM && (*grade->getcourseCode()) == (*newCourseCode))
        {
            return grade;
        }
    }
    return NULL;
}

Students *getStudentByAm(CString *AM)                   // from students csv getting the student with AM ... 
{
    int studentCn = allStudents->size();
    for (int i = 0; i < studentCn; i++)
    {
        Students *student = (*allStudents)[i];
        if ((*student->getAM()) == (*AM))
        {
            return student;
        }
    }
    return NULL;
}

// end helper functions ====================




int main()
{

    ofstream report ("/home/bill/Desktop/Projects/CppGrades/docs/report.csv");  // open the file for the report (name report)

    //Read Csvs 

    allGrades = readGrades();
    allStudents = readStudents();
    allCourses = readCourses();
    //-----------------------------

    int gradeCn = allGrades->size();
    int courseCount = allCourses->size();

    for (int i = 0; i < gradeCn; i++)                                           // loop logic is check if null then check if it is old course
    {                                                                           // if it is we need to check the grades are matching or missing
        Grades *grade = (*allGrades)[i];                                        // if missing pritn it (we have the info) also graping students 
        course_grade_t course = getCourseFromGrade(grade->getcourseCode());     // info for printing (while there check if exists)

        if (course.course != NULL)
        {      
            if (course.isOld) {
                CString *newCourseCode = course.course->getNewCourseCode();
                Grades *newGrade = getNewGrade(newCourseCode, grade->getAM());

                if (!newGrade || newGrade->getgrade() != grade->getgrade())
                {
                    if (newGrade)
                    {

                        Students *student = getStudentByAm(grade->getAM());
                        if (student)
                        {
                            CString studentName = *student->getname();
                            CString courseName = *course.course->getNewCourseTitle();
                            float oldGradeVal = grade->getgrade();
                            float newGradeVal = newGrade->getgrade();

                            report << " old grade != new grade student with name " << studentName.getWord()<< " and AM : " 
                            << grade->getAM()->getWord() <<" at course " << courseName.getWord() << " old grade is : " 
                            << oldGradeVal << " well new grade is : " << newGradeVal<< endl;
                        }
                        else
                        {
                            cout << "no student found with AM " << grade->getAM()->getWord() << " at course : " << endl;
                        }
                    }
                    else
                    {
                        Students *student = getStudentByAm(grade->getAM());
                        if (student)
                        {
                            CString studentName = *student->getname();
                            CString courseName = *course.course->getNewCourseTitle();
                            report << "new grade not found on student with AM : " << grade->getAM()->getWord() << " at course with name : " 
                            << courseName.getWord() << endl;
                        }
                    }
    
                }
            }
        } 
        else 
        {
            CString  notFoundCourseCode = *grade->getcourseCode();
            report << "course : " << notFoundCourseCode.getWord() << " was not found" << endl;
        }
 
    }
    report.close();
}
